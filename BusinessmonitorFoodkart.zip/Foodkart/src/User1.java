/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MohamedSharbudeen
 */
public class User1 {
    
    private String name,mobileno,orderamount,date,userid;
    
    public User1(String name,String mobileno,String orderamount,String date,String userid)
    {
        this.name=name;
        this.mobileno=mobileno;
        this.orderamount=orderamount;
        this.date=date;
        this.userid=userid;
    }
    public String getname(){
        return name;
    }
    public String getmobileno(){
        return mobileno;
    }
    public String userid(){
        return orderamount;
    }
    public String date(){
        return date;
    }
    public String orderamount(){
        return userid;
    }
    
}
